#!/bin/bash
service lighttpd start
python3 /app/config/starttask.py &
python3 /app/config/rtspproxy.py &
# ./heiptv_emulate
tail -f /dev/null