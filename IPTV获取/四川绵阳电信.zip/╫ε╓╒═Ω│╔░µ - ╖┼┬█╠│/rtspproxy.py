import re
import socket
import threading
# 配置目标服务器的地址和端口
server_address = '218.89.44.4'
bad_server = '192.168.102.139'
server_port = 554
#从数据中提取域名或IP地址
def getaddress(response):
    # 定义正则表达式匹配 rtsp:// 后面的域名或IP地址，直到遇到冒号:
    #pattern = r'rtsp://([^:]+)'   #re.search(r'rtsp://([^/:]+:\d+)', url)
    #pattern = r'rtsp://([^/:]+:\d+)'
    pattern = r'rtsp://([^/:]+)(?::(\d+))?'
    # 使用正则表达式查找匹配的内容
    match = re.search(pattern, response.decode('utf-8'))  
    address = match.group(1)
    port = int(match.group(2))    
    # 判断并返回结果
    if match:
        return address,port  # 返回匹配到的内容
    return "0","0" # 如果没有匹配到，返回“0”
#将数据中的ip地址，用ip地址串替换
def replaceip(response,ipv4_address,ipv4_port):
    domain_pattern = r'rtsp://\b[a-zA-Z0-9_.-]+\.[a-zA-Z]{2,}\b'
    pattern = r"rtsp://\d+\.\d+\.\d+\.\d+"
    tosend = re.sub(domain_pattern, "rtsp://"+ipv4_address, response.decode('utf-8'))
    tosend = re.sub(pattern,"rtsp://"+ipv4_address,tosend)
    pattern = r'(?<=://)([^/:]+)(?::\d+)?(?=/|$)'
    replacement = f'\\1:{ipv4_port}'
    tosend = re.sub(pattern, replacement, tosend)  
    return tosend.encode('utf-8')
def replacelocation(request,location):
    print(f"监控location的值22为:\n{location}")
    oldrequest_str = request.decode('utf-8')
    old_pattern = r'(rtsp://[^\s]+) RTSP/1.0'
    old_match = re.search(old_pattern, oldrequest_str)
    print(f"[!]old_match为：{old_match.group(1)}")
    new_str = oldrequest_str.replace(old_match.group(1), location)
    print(f"[!]替换后的optin为：{new_str}")
    newrequest = new_str.encode('utf-8')
    return newrequest
#接收服务器数据处理后转发到客户端
def handle_StoC(client_socket,server_socket,clientaddress):
    #处理RTP流的转发
    print(f"开始转发数据")
    try:
        while True:           
            data = server_socket.recv(4096)
            if not data:
                break
            client_socket.sendall(data)
    except Exception as e:
        server_socket.close()
        client_socket.close()
        #print(f"[!]收发错误！关闭连接: {e}")
#接收客户端请求数据处理后转发到服务器
def handle_CtoS(client_socket,server_socket,serveraddress):
    #处理RTP流的转发
    print(f"开始转发数据")
    try:
        while True:           
            data = client_socket.recv(4096)
            if not data:
                break
            server_socket.sendall(data)
    except Exception as e:
        server_socket.close()
        client_socket.close()
        #print(f"[!]收发错误！关闭连接: {e}")
#生成二次握手请求(将OPIONS请求变为DESCRIBE请求)
def describe(firstrequest):
    # 新的 IP 地址和端口号
    new_ip_port = server_address + ":" + str(server_port)
    # 使用正则表达式替换 IP 地址和端口号部分
    original_string = re.sub(r'rtsp://\b[a-zA-Z0-9_.-]+\.[a-zA-Z]{2,}\b:\d+', f'rtsp://{new_ip_port}', firstrequest.decode('utf-8'))
    original_string = re.sub(r'rtsp://\d+\.\d+\.\d+\.\d+:\d+', f'rtsp://{new_ip_port}', original_string)
    # 将字符串按行分割
    lines = original_string.split('\n')
    # 替换第一行的 OPTIONS 为 DESCRIBE
    lines[0] = lines[0].replace('OPTIONS', 'DESCRIBE')
    # 更新 CSeq 的值为 2
    lines[1] = lines[1].replace('CSeq: 1', 'CSeq: 2')
    # 添加 Accept: application/sdp 行
    lines.insert(1, 'Accept: application/sdp')
    # 将修改后的行重新组合为字符串
    new_string = '\n'.join(lines)
    return new_string.encode('utf-8')
#获取转跳响应的Location字段，包含新的地址
def getlocation(response):
    pattern = r'Location:\s*([^\s]+)'
    match = re.search(pattern, response.decode('utf-8'), re.IGNORECASE)
    #print(f"获取的Location的值为:\n{match.group(1)}")
    tosend = match.group(1)
    return tosend
def newoptions(location):
    request = (
        "OPTIONS " + location +" RTSP/1.0\r\n"
        "CSeq: 1\r\n"
        "User-Agent: Lavf62.1.100\r\n\r\n").encode('utf-8')  # 转为字节流
    #print(f"构建options为:{request}")
    return request
#根据首发请求和查询服务器套接字获取新的目标服务器的地址以及新服务器的socket和首发响应。
def getnewserver(firstrequest,server_socket):    
    twotoserver = describe(firstrequest)
    print(f"继续发送服务器的二次请求:\n{twotoserver.decode('utf-8')}") 
    server_socket.sendall(twotoserver)
    response = server_socket.recv(4096)
    print(f"接收到的二次响应:\n{response.decode('utf-8')}")
        
    targetaddress,targetport = getaddress(response)
    if targetaddress == bad_server:
        #print(f"空的目标服务器关闭")
        return
    #print(f"收到转跳命令后，用首次请求数据:\n{firstrequest}")    
    try:
        #print(f"获取二次响应中的实际目标地址:\n{targetaddress}:{targetport}")
        #获取Location
        location = getlocation(response)
        onetoserver = newoptions(location)#
        #server_socket.close()
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.connect((targetaddress, targetport))
        #print(f"重新连接目标服务器地址：{targetaddress}和端口{targetport}\n")
        server_socket.sendall(onetoserver)
        print(f"重新连接发往目标服务器的请求为:\n{onetoserver.decode('utf-8')}")
        response = server_socket.recv(1024)
        print(f"重新连接接收到新服务器响应为:\n{response.decode('utf-8')}")
    except Exception as e:
        server_socket.close()
        #print(f"目标服务器无响应，关闭")
    return server_socket,response,targetaddress,targetport,location
#翻译器，负责将live和sdp进行转换
def Translator(source):
    source_str = source.decode('utf-8')
    if 'playseek' in source_str:
        print("包含回看代码")
        playseek = re.search(r'playseek=\d{14}-\d{14}', source_str)
        playseek_str = playseek.group(0)
        programtime_str = playseek_str.replace("playseek","programbegin").replace("-", "+08&programend=") + "+08"
        print(f"节目时间代码为：\n{programtime_str}")
        target_str = source_str.replace("TVOD","live").replace("smil?","mpg?vcdnid=001&boid=001&contname=&").replace(playseek_str,programtime_str)
    else:
        print("不包含回看代码")
        target_str = source_str.replace("PLTV","live").replace("smil","sdp?vcdnid=001")
    target = target_str.encode('utf-8')
    return target
#处理客户端的请求与服务器的响应
def handle_entrance(client_socket):
    try:
        #默认目标地址为默认的服务器地址
        targetaddress = server_address
        targetport = server_port
        location = ""
        #与目标服务器建立连接
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.connect((targetaddress, targetport))
        #print(f"连接目标服务器")
        ######首次接收客户端的请求
        for once in '1234':
            request = client_socket.recv(1024)
            print(f"接收到的客户端的请求为:\n{request.decode('utf-8')}")
            #提取客户端的访问域名或IP地址
            clientaddress,clientport = getaddress(request)
            print(f"监控location的值为:\n{location}")
            #地址转换为目标服务器
            if location =="":
                toserver = replaceip(request,targetaddress,targetport)
            else:
                print(f"监控location的值为:\n{location}")
                toserver = replacelocation(request,location)
            #判断是直播还是回放
            toserver = Translator(toserver)     
            ##首次将请求转发到目标 RTSP 服务器
            print(f"发往目标服务器的请求为:\n{toserver.decode('utf-8')}")
            server_socket.sendall(toserver)
            # 接收目标服务器的响应
            response = server_socket.recv(4096)
            print(f"接收到服务器响应为:\n{response.decode('utf-8')}")
            #如果不包含会话ID，则重新连接目标服务器
            if once == '1':
                print("该响应不包含会话ID，需要重新连接")
                #获取新的服务器套接字，响应数据，新的服务器地址
                server_socket, response, targetaddress, targetport, location = getnewserver(toserver,server_socket)
                #print("新目标服务器已经重新连接")     
            # 将响应发送回客户端
            toclient = replaceip(response,clientaddress,clientport)       
            print(f"发往客户端的响应为:\n{toclient.decode('utf-8')}")
            client_socket.sendall(toclient)
            ###################直播的搞定，明天看看回放
            
            
            
        ##数据转发
        server_thread = threading.Thread(target=handle_StoC, args=(client_socket,server_socket,clientaddress))
        server_thread.start()
        client_thread = threading.Thread(target=handle_CtoS, args=(client_socket,server_socket,targetaddress))
        client_thread.start()
    except Exception as e:
        # 处理其他 socket 相关的异常
        print(f"连接失败")
        server_socket.close()
        client_socket.close()
        print(f"关闭连接")
def start_proxy():
    #代理服务器绑定554端口并进入监听模式
    proxy_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    proxy_socket.bind(('0.0.0.0', 554))
    proxy_socket.listen(5)
    print("开始监听554端口")
    while True:
        client_socket, addr = proxy_socket.accept()
        print(f"连接 {addr}")
        proxy_handler = threading.Thread(target=handle_entrance, args=(client_socket,))
        proxy_handler.start()
if __name__ == '__main__':
    start_proxy()
